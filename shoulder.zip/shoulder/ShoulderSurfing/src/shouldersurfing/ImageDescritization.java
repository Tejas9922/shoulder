/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shouldersurfing;

import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author Dell
 */
public class ImageDescritization extends JPanel {

    private static final int ROWS = 11;
    private static final int COLS = 7;
    private static final int GAP = 3;
    private JLabel[][] buttonGrid = new JLabel[ROWS][COLS];
    private JLabel[] labels;
    public static String imagePath = "";
    private final int rows = 11; //You should decide the values for rows and cols variables
    private final int cols = 7;
    private final int chunks = rows * cols;
    private final int SPACING = 10;//spacing between split images
    public static String imageid = "";
    public int counter = 0;
    public String imageclick = "";

    public ImageDescritization() {
        setLayout(new GridLayout(ROWS, COLS, GAP, GAP));
        BufferedImage[] imgs = getImages();
        int count = 0;
        for (int row1 = 0; row1 < buttonGrid.length; row1++) {
            for (int col1 = 0; col1 < buttonGrid[row1].length; col1++) {

                final int i1 = row1;
                final int j1 = col1;
                buttonGrid[row1][col1] = new JLabel();
                buttonGrid[row1][col1].setIcon(new ImageIcon(Toolkit.getDefaultToolkit().createImage(imgs[count].getSource())));
                buttonGrid[row1][col1].addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (counter == 0) {
                            System.out.println("you clicked me " + i1 + "#" + j1);
                            imageclick = i1 + "#" + j1;
                            if (imageid.equals("1")) {
                                Details.point1 = imageclick;
                            } else if (imageid.equals("2")) {
                                Details.point2 = imageclick;
                            } else if (imageid.equals("3")) {
                                Details.point3 = imageclick;
                            }
                            JOptionPane.showMessageDialog(ImageDescritization.this, "Please select cell for confirmation");
                            counter++;
                        } else if (counter == 1) {
                            System.out.println("you clicked me " + i1 + "#" + j1);
                            String click1 = i1 + "#" + j1;

                            if (!click1.equals(imageclick)) {
                                JOptionPane.showMessageDialog(ImageDescritization.this, "selected cell does not matched..");
                                counter = 0;
                                return;
                            } else {
                                JOptionPane.showMessageDialog(ImageDescritization.this, "cell matched.. please close the window");
                                
                                if (imageid.equals("1")) {
                                    Details.point1 = click1;                                   
                                } else if (imageid.equals("2")) {
                                    Details.point2 = click1;
                                } else if (imageid.equals("3")) {
                                    Details.point3 = click1;
                                }
                                
                            }
                        }
                    }
                });
                add(buttonGrid[row1][col1]);
                count++;
               
            }
        }
    }

    public BufferedImage[] getImages() {
        if (imagePath.equals("")) {
            return null;
        }
        File file = new File(imagePath); // I have bear.jpg in my working directory
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        BufferedImage image = null;
        try {
            image = ImageIO.read(fis); //reading the image file
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        int chunkWidth = image.getWidth() / cols; // determines the chunk width and height
        int chunkHeight = image.getHeight() / rows;
        int count = 0;
        BufferedImage imgs[] = new BufferedImage[chunks]; //Image array to hold image chunks
        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < cols; y++) {
                //Initialize the image array with image chunks
                imgs[count] = new BufferedImage(chunkWidth, chunkHeight, image.getType());

                // draws the image chunk
                Graphics2D gr = imgs[count++].createGraphics();
                gr.drawImage(image, 0, 0, chunkWidth, chunkHeight, chunkWidth * y, chunkHeight * x, chunkWidth * y + chunkWidth, chunkHeight * x + chunkHeight, null);

                gr.dispose();

            }
        }
        return imgs;
    }

    public static void createAndShowGui() {
        ImageDescritization mainPanel = new ImageDescritization();
        JFrame frame = new JFrame("Image Descritization");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.getContentPane().add(mainPanel);
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }
}
