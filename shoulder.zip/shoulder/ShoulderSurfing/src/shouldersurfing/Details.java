/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shouldersurfing;

/**
 *
 * @author Dell
 */
public class Details {
    public static String img1="";
    public static String img2="";
    public static String img3="";
    public static String point1="";
    public static String point2="";
    public static String point3="";
    public static String username="";
    public static String password="";
}
