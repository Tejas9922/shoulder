/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shouldersurfing;

import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import javax.swing.WindowConstants;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class AnalysisFrame extends ApplicationFrame {

    public AnalysisFrame(String applicationTitle, String chartTitle) {
        super(applicationTitle);

        JFreeChart barChart = ChartFactory.createBarChart(
                chartTitle,
                "Category",
                "Score",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false);

        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
        setContentPane(chartPanel);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }

    @Override
    public void windowClosing(final WindowEvent event) {
        if (event.getWindow() == this) {
            dispose();
        }
    }

    private CategoryDataset createDataset() {

        final String false_time = "false_time";
        final String true_time = "true_time";

        final DefaultCategoryDataset dataset
                = new DefaultCategoryDataset();

        try {
            DBConnection db = new DBConnection();
            String sql = "SELECT * FROM time_analysis";
            ResultSet rs = db.st.executeQuery(sql);
            while (rs.next()) {
                dataset.addValue(rs.getInt("false_time"), rs.getString("scheme_name"), false_time);
                dataset.addValue(rs.getInt("true_time"), rs.getString("scheme_name"), true_time);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return dataset;
    }

    public static void main(String[] args) {
        AnalysisFrame chart = new AnalysisFrame("4-D Authentication Scheme",
                "Time Analysis");
        chart.pack();
        RefineryUtilities.centerFrameOnScreen(chart);
        chart.setVisible(true);
    }
}
