package shouldersurfing;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.*;

public class LoadImage extends JPanel {

    static JLabel label_Horizontal = new JLabel();
    static JLabel label_Vertical = new JLabel();
    private static final int ROWS = 11;
    private static final int COLS = 7;
    private static final int GAP = 2;

    public static ArrayList chars = new ArrayList();
    public static ArrayList num = new ArrayList();
    private JLabel[][] buttonGrid = new JLabel[ROWS][COLS];
    private JLabel[] labels;
    public static String imagePath = "C:\\Users\\SHRI\\Desktop\\image\\firstscreen.jpg";
    public static String point = "";
    private final int rows = 11; //You should decide the values for rows and cols variables
    private final int cols = 7;
    private final int chunks = rows * cols;
    private final int SPACING = 10;//spacing between split images
    public String uname = "";

    public LoadImage(String username) {

        setLayout(new GridLayout(ROWS, COLS, GAP, GAP));
        BufferedImage[] imgs = getImages();

        int count = 0;
        for (int row1 = 0; row1 < buttonGrid.length; row1++) {
            for (int col1 = 0; col1 < buttonGrid[row1].length; col1++) {
                String text = String.format("Button [%d, %d]", row1, col1);
                final int i1 = row1;
                final int j1 = col1;
                buttonGrid[row1][col1] = new JLabel();
                buttonGrid[row1][col1].setIcon(new ImageIcon(Toolkit.getDefaultToolkit().createImage(imgs[count].getSource())));
//                buttonGrid[row1][col1].addMouseListener(new MouseAdapter() {
//                    @Override
//                    public void mouseClicked(MouseEvent e) {
//
//                      
//                    }
//
//                });
                add(buttonGrid[row1][col1]);
                count++;
            }
        }
        uname = username;
    }

    public BufferedImage[] getImages() {
        File file = new File(imagePath); // I have bear.jpg in my working directory
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException ex) {
            //   Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
        BufferedImage image = null;
        try {
            image = ImageIO.read(fis); //reading the image file
        } catch (IOException ex) {
            // Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
            ex.printStackTrace();
        }
        int chunkWidth = image.getWidth() / cols; // determines the chunk width and height
        int chunkHeight = image.getHeight() / rows;
        int count = 0;
        BufferedImage imgs[] = new BufferedImage[chunks]; //Image array to hold image chunks
        for (int x = 0; x < rows; x++) {
            for (int y = 0; y < cols; y++) {
                //Initialize the image array with image chunks
                imgs[count] = new BufferedImage(chunkWidth, chunkHeight, image.getType());

                // draws the image chunk
                Graphics2D gr = imgs[count++].createGraphics();
                gr.drawImage(image, 0, 0, chunkWidth, chunkHeight, chunkWidth * y, chunkHeight * x, chunkWidth * y + chunkWidth, chunkHeight * x + chunkHeight, null);

                gr.dispose();

            }
        }
        return imgs;
    }

    public static void createAndShowGui(final String uname) {
        LoadImage mainPanel = new LoadImage(uname);
        mainPanel.setBounds(150, 90, 290, 300);
        final JFrame frame = new JFrame("LoadImage");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(null);

        JButton button_Ok = new JButton();
        button_Ok.setText("Ok");
        button_Ok.setBounds(48, 30, 50, 30);
        button_Ok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // LoadImage.point
                DBConnection db = new DBConnection();
                String alphabet[] = {"a", "b", "c", "d", "e", "f", "g"};
                String[] points = LoadImage.point.split("#");
                int row = Integer.parseInt(points[0]);
                int col = Integer.parseInt(points[1]);
                String point1 = num.get(row).toString();
                String point2 = chars.get(col).toString();
                String point3 = alphabet[col];
                if (point2.equals(point3)) {
                    if (points[0].equals(point1)) {
                        JOptionPane.showMessageDialog(frame, "Login Successfully !!!!");
                        String sql = "UPDATE time_analysis SET true_time=true_time+1 WHERE scheme_name='graphical_based'";
                        try {
                            db.st.executeUpdate(sql);
                        } catch (SQLException ex) {
                            Logger.getLogger(LoadImage.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        BankHome bk = new BankHome(uname);
                        bk.setVisible(true);
                        bk.setResizable(false);
                        frame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(frame, "points are not equal " + point1 + "#" + point2);
                        String sql = "UPDATE time_analysis SET false_time=false_time+1 WHERE scheme_name='graphical_based'";
                        try {
                            db.st.executeUpdate(sql);
                        } catch (SQLException ex) {
                            Logger.getLogger(LoadImage.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    }

                } else {
                    JOptionPane.showMessageDialog(frame, "points are not equal " + point1 + "#" + point2);
                }
            }
        });
        frame.add(button_Ok);

        JButton button_UP = new JButton();
        button_UP.setText("^");
        button_UP.setBounds(48, 65, 50, 30);
        button_UP.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                downwardVertical();
            }
        });

        frame.add(button_UP);

        label_Vertical.setVerticalAlignment(JLabel.TOP);
        label_Vertical.setText("<html>V<br>e<br>r<br>t<br>i<br>c<br>a<br>l</html>");
        label_Vertical.setBounds(78, 95, 50, 400);
        frame.add(label_Vertical);

        JButton button_Down = new JButton();
        button_Down.setText("v");
        button_Down.setBounds(48, 400, 50, 30);
        button_Down.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                upwardVertical();
            }
        });
        frame.add(button_Down);

        JButton button_Left = new JButton();
        button_Left.setText("<");
        button_Left.setBounds(100, 30, 50, 30);
        button_Left.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                previousHorizontal();
            }
        });
        frame.add(button_Left);

        label_Horizontal.setText("Horizontal");
        label_Horizontal.setBounds(145, 20, 300, 50);
        frame.add(label_Horizontal);

        JButton button_Right = new JButton();
        button_Right.setText(">");
        button_Right.setBounds(450, 30, 50, 30);
        button_Right.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                forwardHorizontal();
            }
        });
        frame.add(button_Right);

        frame.add(mainPanel);
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
        frame.setSize(550, 550);
        fillHorizontal();
        fillVertical();
        // frame.add(new JButton("Left"));
        frame.setVisible(true);
    }

    public static void upwardVertical() {
        String temp = num.get(num.size() - 1).toString();
        String label = "<html>";
        //make a loop to run through the array list
        for (int i = num.size() - 1; i > 0; i--) {
            //set the last element to the value of the 2nd to last element
            num.set(i, num.get(i - 1));

            //set the first element to be the last element
        }
        num.set(0, temp);
        for (int i = 0; i < num.size(); i++) {
            label = label + " " + num.get(i) + "<br><br>";
        }
        label = label + "     </html>      ";
        label_Vertical.setText(label);
        System.err.println("chars" + num);

    }

    public static void downwardVertical() {
        String temp = num.get(0).toString();
        String label = "<html>";
        //make a loop to run through the array list
        for (int i = 1; i < num.size(); i++) {
            //set the last element to the value of the 2nd to last element
            num.set(i - 1, num.get(i));

            //set the first element to be the last element
        }
        num.set(num.size() - 1, temp);
        for (int i = 0; i < num.size(); i++) {
            label = label + " " + num.get(i) + "<br><br>";
        }
        label = label + " </html>";
        label_Vertical.setText(label);
        System.err.println("chars" + num);

    }

    public static void forwardHorizontal() {
        String temp = chars.get(chars.size() - 1).toString();
        String label = "";
        //make a loop to run through the array list
        for (int i = chars.size() - 1; i > 0; i--) {
            //set the last element to the value of the 2nd to last element
            chars.set(i, chars.get(i - 1));

        }
        chars.set(0, temp);
        for (int i = 0; i < chars.size(); i++) {
            label = label + "           " + chars.get(i);
        }
        label_Horizontal.setText(label);
        System.err.println("chars" + chars);
    }

    public static void previousHorizontal() {
        String temp = chars.get(0).toString();
        String label = "";
        //make a loop to run through the array list
        for (int i = 1; i < chars.size(); i++) {
            //set the last element to the value of the 2nd to last element
            chars.set(i - 1, chars.get(i));
            //set the first element to be the last element
        }
        chars.set(chars.size() - 1, temp);
        for (int i = 0; i < chars.size(); i++) {
            label = label + "           " + chars.get(i);
        }
        label_Horizontal.setText(label);
        System.err.println("previous-" + chars);
    }

    public static void fillVertical() {
        String[] number = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"};
        Random rnd = new Random();
        String label = "<HTML>";
        //ArrayList num = new ArrayList();
        for (int i = 0; i < number.length; i++) {

            String ss = number[rnd.nextInt(number.length)];
            if (!num.contains(ss)) {
                num.add(ss);
                label = label + "" + ss + "<br><br>";
            } else {
                i--;
            }

        }
        label = label + "</HTML>";
        label_Vertical.setText(label);
        System.out.println("" + num);
    }

    public static void fillHorizontal() {
        String[] alpha = {"a", "b", "c", "d", "e", "f", "g"};
        Random rnd = new Random();
        String label = "";
        // ArrayList chars = new ArrayList();
        for (int i = 0; i < alpha.length; i++) {

            String ss = alpha[rnd.nextInt(alpha.length)];
            if (!chars.contains(ss)) {
                chars.add(ss);
                label = label + "           " + ss;
            } else {
                i--;
            }

        }
        label_Horizontal.setText(label);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // createAndShowGui();
            }
        });
    }
}
